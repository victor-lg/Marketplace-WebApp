package com.admin;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Admin8106Application {

	public static void main(String[] args) {
		SpringApplication.run(Admin8106Application.class, args);
	}

}
